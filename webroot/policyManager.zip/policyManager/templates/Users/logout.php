<div>
    <div>
        <h2>You are currently Logged out</h2>
    </div>
</div>