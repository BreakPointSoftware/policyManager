<div>
    <div>
        <h2><?= __('You are currently Logged out')?></h2>
    </div>
</div>