
<div class="row">
    <!-- Consider refactoring into an element / compent given time #Greg #Return-->
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Form->postLink(
                __('Delete'),
                ['action' => 'delete', $policy->id],
                ['confirm' => __('Are you sure you want to delete # {0}?', $policy->id), 'class' => 'side-nav-item']
            ) ?>
            <?= $this->Html->link(__('List Policies'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>

    <div class="column-responsive column-80">
        <div class="policies form content">
            <?= $this->Form->create($policy) ?>
            <fieldset>
                <legend><?= __('Edit Policy Components') ?></legend>
                <?php
                    $policyComponentCount = 0;
                    foreach($policy->policy_components as $policyComponent) {
                        echo '<legend> '. __('Component '). $policyComponentCount.'</legend>';
                        echo $this->Form->control('policy_components.'.$policyComponentCount.'.value',['label' => 'Component Tag']);
                        echo $this->Form->control('policy_components.'.$policyComponentCount.'.replacement',['label' => 'Value to replace with'] );
                        $policyComponentCount++;
                    }
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>`
