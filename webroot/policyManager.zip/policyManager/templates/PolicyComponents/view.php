<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\PolicyComponent $PolicyComponent
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Component'), ['action' => 'edit', $policyComponent->id], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Component'), ['action' => 'delete', $policyComponent->id], ['confirm' => __('Are you sure you want to delete # {0}?', $policyComponent->id), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Component'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Component'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="policy_component view content">
            <h3><?= h($renderFriendly->title) ?></h3>
            <table>
                <tr>
                    <th><?= __('Component Name') ?></th>
                    <td><?= __($policyComponent->name) ?></td>
                </tr>
                <tr>
                    <th><?= __('Description') ?></th>
                    <td><?= h($policyComponent->description) ?></td>
                </tr>
                <tr>
                    <th><?= __('Value') ?></th>
                    <td><?= h($policyComponent->value) ?></td>
                </tr>
                <tr>
                    <th><?= __('Created') ?></th>
                    <td><?= h($policyComponent->created) ?></td>
                </tr>
                <tr>
                    <th><?= __('Modified') ?></th>
                    <td><?= h($policyComponent->modified) ?></td>
                </tr>
            </table>
            <div class="related">
                <h4><?= __('Used in Policies') ?></h4>
                <?php if (!empty($policyComponent->policy_components_policies)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Policy Id') ?></th>
                            <th><?= __('User Id') ?></th>
                            <th class="actions"><?= __('Actions') ?></th>
                        </tr>
                        <?php foreach ($policyComponent->policy_components_policies as $policyUsed) : ?>
                        <tr>
                            <td><?= h($policyUsed->policy_id) ?></td>
                            <td><?= h($policyUsed->policy_component_id) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('View'), ['controller' => 'EditorPolicies', 'action' => 'view', $policyUsed->policy_id]) ?>
                                <?= $this->Html->link(__('Edit'), ['controller' => 'EditorPolicies', 'action' => 'edit', $policyUsed->policy_id]) ?>
                                <?= $this->Form->postLink(__('Delete'), ['controller' => 'EditorPolicies', 'action' => 'delete', $policyUsed->policy_id], ['confirm' => __('Are you sure you want to delete # {0}?', $editorPolicies->policy_id)]) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
            <div class="debug">
                <h4><?= __('Debug output of $policyComponent') ?></h4>
                <?= print_r($policyComponent); ?>
                
            </div>
        </div>
    </div>
</div>
