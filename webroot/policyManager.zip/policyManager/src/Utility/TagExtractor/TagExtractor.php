<?php
namespace App\Utility\TagExtractor;

use Cake\Core\Exception\Exception;

//Helper class for extracting Tags and replacing them
//Tags are assumed to start with prefix and be mixed case
//they will allways be pushed to upper case for matching and storage 

//Consider returning the string with upper case tags in place for cleaness 
class TagExtractor
{
    public static function extractTags($aPrefix, $aStringToGrep) 
    {
        //Escape the prefix chat
        $prefixEscaped = "\\" . $aPrefix;
        $regexString = '^\s*('. $prefixEscaped .'[a-zA-Z0-9_]+)\s*^';
        $capturedComponents = array();

        //We can take in a prefix of any type, so we can extend it to @ and % tags if needed
        preg_match_all($regexString,$aStringToGrep,$matches,PREG_PATTERN_ORDER);
        
        if ($matches) {

            foreach($matches as $group)
            {
                foreach ($group as $match) {
                    $trimed = trim($match);
                    $capturedComponents[] = strtoupper($trimed);
                }
            }
        }
        else {
            $capturedComponents = null;
        }
        return $capturedComponents;
    }

    //Replace tags in source text with actual strings needed
    public static function replaceTags($aTextToBuild, $aTagArray)
    {
        if(is_array($aTagArray)) {
            foreach($aTagArray as $tagToReplace) {

                //Escape the prefix chat
                $prefixEscaped = "\\" . $tagToReplace['tag'];
                $regexString = '^('. $prefixEscaped .')^i';     //Using I to set case insensitive
                $aTextToBuild = preg_replace($regexString, $tagToReplace['replacement'], $aTextToBuild);
            }
            return $aTextToBuild;
        } else {
            return null;
        }
    }
    
    //Clean the source text so all tags are displayed in upper case
    public static function cleanTagsInSource($aTextToClean,$aTagArray) {
        
        if(is_array($aTagArray))
        {
            foreach($aTagArray as $tagToReplace) {

                //Escape the prefix chat
                $prefixEscaped = "\\" . $tagToReplace['tag'];
                $regexString = '^('. $prefixEscaped .')*^i';            //Using I to set case insensitive
                preg_replace($regexString, $tagToReplace['tag'], $aTextToClean);
            }
            return $aTextToClean;
        } else {
            return null;
        }
    }
    //Helper for packing 2 element Array
    public static function packTag($aTag,$aReplacement =null) {
        if(is_string($aTag)) {
            $packedTags = [ 'tag' => $aTag, 'replacement' => $aReplacement];
            return $packedTags;
        }
        else {
            return null;        //Need to think about hooking an appropriate error handler 
        }
    }

    //Helper for making $aTagArray
    public static function buildTagArray($aTagsToPack,$aReplacementsToPack = null)
    {
        $isSafeToPack = false;
        $packNulls =false;
        $tagsCount = count($aTagsToPack);
        $replacementsCount = count($aReplacementsToPack);

        //Work out how we want to pack the data and return it.
        if(is_array($aTagsToPack)) {
            if(is_array($aReplacementsToPack)) {
                //Check if our arrays are matching
                if($tagsCount === $replacementsCount) {
                    //Safe to pack
                    $isSafeToPack = true;
                } 
            } elseif ($aReplacementsToPack == null) {
                //ony one parameter passed - so just pack the Tags
                $isSafeToPack = true;
                $packNulls = true;
            }
        }
        

        if($isSafeToPack) { 
            for ($currentIndex=0; $currentIndex <  $tagsCount; $currentIndex++) { 
                $tag = $aTagsToPack[$currentIndex];
                $replacement = ($packNulls ? null : $aReplacementsToPack[$currentIndex]);
                $packedTags[] = TagExtractor::packTag($tag,$replacement);

            }

        }
        return $packedTags;
    }

    

}

/* #not reference for error handling, something to look into later
class MissingWidgetException extends Exception
{
    // Context data is interpolated into this format string.
    protected $_messageTemplate = 'Seems that %s is missing.';

    // You can set a default exception code as well.
    protected $_defaultCode = 404;
}

throw new MissingWidgetException(['widget' => 'Pointy']);
}
*/
?>