<?php 
namespace App\Utility\Helpers;

class IntegrityEnum {
    const Invalid = 1;
    const Valid = 2;
}
?>