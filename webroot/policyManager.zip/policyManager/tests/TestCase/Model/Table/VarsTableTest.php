<?php
declare(strict_types=1);

namespace App\Test\TestCase\Model\Table;

use App\Model\Table\VarsTable;
use Cake\ORM\TableRegistry;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\VarsTable Test Case
 */
class VarsTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\VarsTable
     */
    protected $Vars;

    /**
     * Fixtures
     *
     * @var array
     */
    protected $fixtures = [
        'app.Vars',
        'app.PolicyVars',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp(): void
    {
        parent::setUp();
        $config = TableRegistry::getTableLocator()->exists('Vars') ? [] : ['className' => VarsTable::class];
        $this->Vars = TableRegistry::getTableLocator()->get('Vars', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown(): void
    {
        unset($this->Vars);

        parent::tearDown();
    }

    /**
     * Test initialize method
     *
     * @return void
     */
    public function testInitialize(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
